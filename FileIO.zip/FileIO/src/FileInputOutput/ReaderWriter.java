package FileInputOutput;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReaderWriter {
	public static void main(String[] args) {
		FileReader fr= null;
		FileWriter fw = null;
		
		try {
			fr = new FileReader("/Users/2268594/Documents/FileInputDEmo.txt");
			fw= new FileWriter("/Users/2268594/Documents/ReaderWriterDemo.txt");
			int ch;
			while((ch=fr.read())!=-1){
				fw.write(ch);
			}
			System.out.println("File copied successfully");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		try {
			fr.close();
			fw.close();	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}

}
