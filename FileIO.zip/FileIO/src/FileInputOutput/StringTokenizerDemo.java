package FileInputOutput;
import java.util.*;
public class StringTokenizerDemo {
	public static void main(String[] args) {
		// this will split the string of words
		String s = "You are the creator of your destiny";
		StringTokenizer st = new StringTokenizer(s);
		
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		// this will split the string of words and the commas too.
		String s1 = "You, are, the, creator, of, your, destiny";
		StringTokenizer st1 = new StringTokenizer(s1,",", true );
		
		while(st1.hasMoreTokens()) {
			System.out.println(st1.nextToken());
		}
	}

}
