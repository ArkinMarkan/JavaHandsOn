package SerializationDeserialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializantionDemo {

	public static void main(String[] args) throws FileNotFoundException,IOException {

			FileOutputStream fos = new FileOutputStream("/Users/2268594/Documents/Serialez.sr");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			Employee emp = new Employee(1, "Arkin", 100000, 12345);
			oos.writeObject(emp);
			System.out.println("Employee Object Serialized");
		} 
	
	}