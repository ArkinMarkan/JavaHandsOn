package ThreadCommunication;

public class mainThread {
	public static void main(String[] args) throws InterruptedException {
		MyThread mt= new MyThread();
		mt.start();
		
		synchronized(mt) {
			System.out.println("Main Thread is going to wait");
			mt.wait();
			System.out.println("Main thread notified");
			System.out.println(mt.total);
			
		}
	}
}
