package Multithreads;
import java.util.Scanner;

public class TimeThread extends Thread {
	static int n,sum=0;
	public static void main(String[] args) {
		// the below is the method to know the starting time of thread in milliseconds.
		long start = System.currentTimeMillis();
		System.out.println("Sum of First 'N' Numbers" );
		System.out.println("Enter a value");
		Scanner sc= new Scanner(System.in);
		
		n=sc.nextInt();
		TimeThread jd = new TimeThread();
		jd.start();
		try {
			jd.join();
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Sum of First "+n+" No. is = "+sum);
		// the below method is used to get the end time of the thread in milliseconds.
		long end = System.currentTimeMillis();
		System.out.println("The total time taken = "+ (end - start)/1000+" seconds");
	}
	
	public void run() {
		for(int i=1;i<=n;i++) {
			sum +=i;
		}
	}

}
