package Multithreads;

import java.util.Scanner;

public class JoinDemo extends Thread {
	static int n,sum=0;
	public static void main(String[] args) {
		System.out.println("Sum of First 'N' Numbers" );
		System.out.println("Enter a value");
		Scanner sc= new Scanner(System.in);
		
		n=sc.nextInt();
		JoinDemo jd = new JoinDemo();
		jd.start();
		try {
			jd.join();
			//the above method is used to continue the thread or process till it completely ends.
			// this will make sure that the run method compiles till end.
			// this will run the below code afterwards.
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Sum of First "+n+" No. is = "+sum);
	}
	
	public void run() {
		for(int i=1;i<=n;i++) {
			sum +=i;
		}
	}

}
