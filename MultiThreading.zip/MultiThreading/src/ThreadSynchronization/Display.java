package ThreadSynchronization;

public class Display {
	public synchronized void sayHello(String name) {
		for(int i=1;i<=10;i++) {
			System.out.println("How are you "+name);
		}
	}
}
