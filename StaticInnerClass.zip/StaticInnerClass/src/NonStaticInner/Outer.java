package NonStaticInner;

public class Outer {
	
	void f1() {
		System.out.println("Non static method");
	}
	class Inner{
		void f2() {
			System.out.println("Non static method inside the non-static Inner class");
		}
	}
public static void main(String[] args) {
	Outer a = new Outer();
	a.f1();
	
	Outer.Inner b= a.new Inner();
	b.f2();
	
}
}
