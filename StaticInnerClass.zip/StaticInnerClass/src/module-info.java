/**
 * 
 */
/**
 * 
 */
module StaticInnerClass {
}