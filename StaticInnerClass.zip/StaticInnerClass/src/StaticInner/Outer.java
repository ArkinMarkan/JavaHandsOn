package StaticInner;

public class Outer {
	
	static void f1() {
		System.out.println("Outer Static Method");
	}
	
	static class Inner{
		static void f2() {
			System.out.println("Static method inside the Static Inner Class");
		}
		void f3() {
			System.out.println("Non-Static method inside the Static Inner Class");
		}
	}

	public static void main(String[] args) {
		Outer.f1();
		Outer.Inner.f2();
		Outer.Inner obj= new Outer.Inner();
		obj.f3();
	}

}
