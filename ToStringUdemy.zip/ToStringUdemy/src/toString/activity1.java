package toString;

public class activity1 {
	
	private int meterNo;
	public int getMeterNo() {
		return meterNo;
	}


	public void setMeterNo(int meterNo) {
		this.meterNo = meterNo;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	private String name;
	private String address;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
