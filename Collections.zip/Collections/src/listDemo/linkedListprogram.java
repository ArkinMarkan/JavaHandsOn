package listDemo;

import java.util.*;

public class linkedListprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object obj[]= new Object[100000];
		for(int i =0; i<obj.length; i++) {
			obj[i] = new Object();
		}
		List<Object>list = new LinkedList<>();
		long start= System.currentTimeMillis();
		for(Object object:obj) {
			list.add(object);		}
	long end = System.currentTimeMillis();
	System.out.println("Time Taken = " + (end- start));
}
}