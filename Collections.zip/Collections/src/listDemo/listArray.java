package listDemo;

import java.util.*;

public class listArray {
	public static void main(String[] args) {
		List<Integer> list= new ArrayList<>();
		for(int i =10 ; i<=100; i+=10) {
			list.add(i);
	}
	System.out.println("List: "+list);
	list.add(3, 34);
	System.out.println("After Insertion List: "+list);
	
	
	//addAll method to add the elements of list to other list 
	List<Integer> slist = new ArrayList<>();
	slist.add(10);
	slist.add(55);
	slist.add(31);
	slist.add(41);
	System.out.println("Second List = "+slist);
	
	list.addAll(4,slist);
	System.out.println("List after add All Method = "+list);
	
	
	//Search Elements 
	//Contains method
	if(list.contains(21)) {
		System.out.println("The list has element");
	} else {
		System.out.println("the list does not have element");
	}
	
	}
}
