package setDemo;

import java.util.*;
import java.util.Random;

public class hashProgram {
	public static void main(String[] args) {
		Random obj = new Random();
		List<Integer> list = new ArrayList<>();
		for(int i=0;i<=10;i++) {
			int number = obj.nextInt(4);
			list.add(number);
		}
		System.out.println("List = "+list );
		Set<Integer> set = new HashSet<>(list);
		System.out.println("set = "+set);
	}
}
