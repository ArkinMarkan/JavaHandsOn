package setDemo;

import java.util.*;
import java.util.Random;

public class treeSetProgram {
	public static void main(String[] args) {
		Random obj = new Random();
		Set<Integer> set = new TreeSet<>();
		
		for(int i=1;i<=10;i++) {
			int num=obj.nextInt(100);
			set.add(num);
			System.out.println(num);
		}
		System.out.println("Tree Set Elements :- "+set);
	}

}
