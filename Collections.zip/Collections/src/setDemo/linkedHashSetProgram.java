package setDemo;

import java.util.*;

public class linkedHashSetProgram {

	public static void main(String[] args) {
		Random obj = new Random();
		LinkedHashSet<Integer> set = new LinkedHashSet<>();
		
		for(int i=1;i<=10;i++) {
			int num=obj.nextInt(100);
			set.add(num);
			System.out.println(num);
		}
		System.out.println("Linked Hash Set Elements :- "+set);
	}
}
