package SortString;

import java.util.*;

public class sortStringProgram{
	public static void main(String[] args) {
		
	Set<String> set = new TreeSet<>();
	set.add("abc");
	set.add("def");
	set.add("xyzabc");
	set.add("abcd");
	set.add("efgh");
	
	for(String obj:set) {
		System.out.println(obj);
	}
	}
}
