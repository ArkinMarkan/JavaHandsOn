package SortString;
import java.util.*;

public class test implements Comparator<String>{
	@Override
	public int compare(String a1, String a2) {
		int l1=a1.length();
		int l2=a2.length();
		
		if(l1<l2) {
			return -1;
		} else if(l1>l2) {
			return 1;
		} else {
			return a1.compareTo(a2);
		}
	}

}
