package hashMap;

import java.util.*;

public class identityHMProgram {

	public static void main(String[] args) {
		// the Use of identity hash map is to make a difference in the values of 
		// id with same id's.
		Map<Integer,String> map= new IdentityHashMap<>();
		//------------------------------^here if we put only hashmap it will compare the
		// ------------------------------values, which will be same so output will be 
		//-------------------------------only 1 id and name
		Integer id1= new Integer(10);
		Integer id2 = new Integer(10);
		
		map.put(id1, "Arkin");
		map.put(id2, "Markan");
		
		System.out.println(map);
	}

}
