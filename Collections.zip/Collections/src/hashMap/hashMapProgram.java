package hashMap;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class hashMapProgram {
	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		
		map.put("Arkin", 101);
		map.put("Paras", 102);
		map.put("Ankush", 103);
		map.put("Kanishk", 104);
		map.put("Manas", 105);
		
		Set<String> keySet = map.keySet();
		System.out.println("Keys :- "+keySet);
		
		Collection<Integer> values = map.values();
		System.out.println("values: - "+ values);
		
		for(String key: keySet) {
			System.out.println("key : "+key+", Value : "+map.get(key));
		}
	}
}
