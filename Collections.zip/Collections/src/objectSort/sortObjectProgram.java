package objectSort;

import java.util.Set;
import java.util.*;

public class sortObjectProgram {
	public static void main(String[] args) {
		Set<Employee> set= new TreeSet<>();
		set.add(new Employee(100,"Arkin"));
		set.add(new Employee(101,"Paras"));
		set.add(new Employee(102,"Ankush"));
		set.add(new Employee(103,"Kanishk"));
		set.add(new Employee(104,"Manas"));
		
		for(Employee employee:set) {
			System.out.println(employee.id);
			System.out.println(employee.name);
		}
		
	}
}
