/**
 * 
 */
/**
 * 
 */
module StringDemo {
}