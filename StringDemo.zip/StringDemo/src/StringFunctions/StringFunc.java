package StringFunctions;

public class StringFunc {
	public static void main(String[] args) {
		
	String s="Hello World";
	String s1="abc";
	String s2="xyz";
	String s3="abc";
	
	// ==
	System.out.println(s1==s2);
	System.out.println(s1==s3);
	
	//equals method
	System.out.println(s1.equals(s3));
	System.out.println(s1.equals(s2));
	
	//lenght of string and will count space also 
	System.out.println("Length of string "+s+" is - "+s.length());
	
	//to find index of particular character
	System.out.println("The character is located at location "+s.indexOf('o'));
	
	//to find charcter at particular index
	System.out.println("The character at this index is "+s.charAt(4));
	
	//substring 
	System.out.println("The substring starting from location 1 - "+s.substring(1));
	System.out.println("The substring starting from location 1 to 4 - "+s.substring(1, 5));
	
	//split string 
	String[] result = s.split(" ");
	for(int i=0;i<result.length;i++) {
		System.out.println(result[i]);
	}
	
	//replace method
	System.out.println("The replaced version of string is - "+s.replace('l', 'k'));
	
	//UpperCase
	System.out.println(s.toUpperCase());
	
	//LowerCase
	System.out.println(s.toLowerCase());
	}}
