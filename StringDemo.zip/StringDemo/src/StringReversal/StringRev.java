package StringReversal;

public class StringRev {
	
	public String firstWay(String actual) {
	
	String reversed="";
	for(int i=actual.length();i>0;i--) {
		reversed += actual.charAt(i-1);
	}
	return reversed;
	}
	public static void main(String[] args) {
		String str="ARKIN";
		StringRev sr= new StringRev();
		System.out.println(sr.firstWay(str));
	}

}
