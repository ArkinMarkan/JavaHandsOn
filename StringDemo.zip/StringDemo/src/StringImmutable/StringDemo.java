package StringImmutable;

public class StringDemo {
	public static void main(String[] args) {
		User user1 =new User();
		User user2 = new User();
		
		System.out.println(user1);
		System.out.println(user2);
		
		String s1="abc";
		String s2="xyz";
		String s3="abc";
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
	}
}
