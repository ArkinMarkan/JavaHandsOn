package StringImmutable;

public class User {
	

}
